library(keras)
library(tensorflow)
library(ggplot2)
library(gridExtra)

# Set seed for reproducibility
set.seed(123)
tf$random$set_seed(123)

# Load and preprocess data
load_and_preprocess_data <- function() {
  # Load Fashion MNIST dataset
  fashion_mnist <- dataset_fashion_mnist()
  
  # Split into train and test
  x_train <- fashion_mnist$train$x
  y_train <- fashion_mnist$train$y
  x_test <- fashion_mnist$test$x
  y_test <- fashion_mnist$test$y
  
  # Reshape and normalize
  x_train <- array_reshape(x_train, c(nrow(x_train), 28, 28, 1))
  x_test <- array_reshape(x_test, c(nrow(x_test), 28, 28, 1))
  x_train <- x_train / 255
  x_test <- x_test / 255
  
  # One-hot encode labels
  y_train <- keras::to_categorical(y_train, num_classes = 10)
  y_test <- keras::to_categorical(y_test, num_classes = 10)
  
  return(list(
    train = list(x = x_train, y = y_train),
    test = list(x = x_test, y = y_test)
  ))
}


# Build CNN model
build_cnn_model <- function() {
  model <- keras_model_sequential() %>%
    # Layer 1: Convolutional
    layer_conv_2d(filters = 32, kernel_size = c(3, 3), 
                  activation = "relu", input_shape = c(28, 28, 1)) %>%
    # Layer 2: Max Pooling
    layer_max_pooling_2d(pool_size = c(2, 2)) %>%
    # Layer 3: Convolutional
    layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = "relu") %>%
    # Layer 4: Max Pooling
    layer_max_pooling_2d(pool_size = c(2, 2)) %>%
    # Layer 5: Flatten
    layer_flatten() %>%
    # Layer 6: Dense
    layer_dense(units = 128, activation = "relu") %>%
    # Output layer
    layer_dense(units = 10, activation = "softmax")
  
  return(model)
}

# Main execution
main <- function() {
  # Load and preprocess data
  data <- load_and_preprocess_data()
  x_train <- data$train$x
  y_train <- data$train$y
  x_test <- data$test$x
  y_test <- data$test$y
  
  # Build model
  model <- build_cnn_model()
  
  # Compile model
  model %>% compile(
    optimizer = optimizer_adam(),
    loss = "categorical_crossentropy",
    metrics = c("accuracy")
  )
  
  # Train model
  history <- model %>% fit(
    x_train, y_train,
    epochs = 10,
    batch_size = 128,
    validation_split = 0.2,
    verbose = 1
  )
  
  # Evaluate model
  score <- model %>% evaluate(x_test, y_test, verbose = 0)
  cat("Test loss:", score["loss"] %>% unname(), "\n")
  cat("Test accuracy:", score["accuracy"] %>% unname(), "\n")
  
  # Make predictions on two sample images
  sample_images <- x_test[1:2,,,, drop = FALSE]
  predictions <- predict(model, sample_images)
  predicted_classes <- apply(predictions, 1, which.max) - 1
  
  # Class names
  class_names <- c("T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
                   "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot")
  
  # Create and save prediction plots
  plot_list <- list()
  for (i in 1:2) {
    img <- sample_images[i,,, 1]
    df <- data.frame(
      x = rep(1:28, each = 28),
      y = rep(28:1, times = 28),
      value = as.vector(img)
    )
    
    plot_list[[i]] <- ggplot(df, aes(x = x, y = y, fill = value)) +
      geom_tile() +
      scale_fill_gradient(low = "white", high = "black") +
      theme_void() +
      theme(legend.position = "none") +
      ggtitle(paste("Predicted:", class_names[predicted_classes[i] + 1]))
  }
  
  # Arrange and save plots
  grid <- grid.arrange(grobs = plot_list, ncol = 2)
  ggsave("fashion_mnist_predictions_r.png", grid, width = 8, height = 4)
  
  # Print predictions
  cat("\nSample Predictions:\n")
  for (i in 1:2) {
    cat("Image", i, "predicted as:", class_names[predicted_classes[i] + 1], "\n")
  }
}

# Run main function
main()
